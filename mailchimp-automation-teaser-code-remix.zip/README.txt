A Pen created at CodePen.io. You can find this one at https://codepen.io/benHadman/pen/ZrMxgm.

 A personal remix using SVG and GSAP of the nice teaser animation from Mailchimp. You can see the original here https://mailchimp.com/features/automation/

From: http://dudesgoods.com